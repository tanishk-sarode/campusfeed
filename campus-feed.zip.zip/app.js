// NIT Rourkela Campus Feed Application
class CampusFeedApp {
    constructor() {
        this.posts = [];
        this.currentFilter = 'all';
        this.currentPostId = null;
        this.userReactions = new Map();
        this.userResponses = new Map();
        this.commentCounter = 1000;
        
        this.init();
    }

    init() {
        this.loadSampleData();
        this.bindEventListeners();
        this.renderFeed();
        this.initSmartInput();
    }

    loadSampleData() {
        // Sample posts data with enhanced structure
        this.posts = [
            {
                id: 1,
                type: "event",
                title: "Docker Workshop - Advanced Container Management",
                description: "Join us for an intensive Docker workshop covering container orchestration, deployment strategies, and best practices for modern development workflows.",
                location: "CSE Lab, NIT Rourkela",
                date: "2025-09-05",
                time: "17:00",
                department: "Computer Science & Engineering",
                author: "user_123",
                timestamp: "2025-08-29T10:30:00Z",
                responses: { going: 45, interested: 23, notGoing: 5 },
                reactions: { "👍": 12, "❤️": 8, "🔥": 15 },
                comments: []
            },
            {
                id: 2,
                type: "lost_found",
                title: "Lost: Black Leather Wallet",
                description: "Lost my black leather wallet near the central library yesterday evening around 6 PM. Contains important IDs and some cash. Please contact if found.",
                location: "Central Library, NIT Rourkela",
                itemType: "lost",
                author: "user_456",
                timestamp: "2025-08-28T18:30:00Z",
                reactions: { "😢": 3, "👍": 7 },
                comments: [
                    {
                        id: 101,
                        content: "I'll keep an eye out for it. Which floor of the library were you on?",
                        author: "user_789",
                        timestamp: "2025-08-28T19:00:00Z",
                        reactions: {"👍": 2},
                        replies: [
                            {
                                id: 102,
                                content: "Thanks! I was mostly on the 2nd floor in the reading section.",
                                author: "user_456",
                                timestamp: "2025-08-28T19:15:00Z",
                                reactions: {},
                                replies: []
                            }
                        ]
                    }
                ]
            },
            {
                id: 3,
                type: "announcement",
                title: "New Semester Timetable Released",
                description: "The official timetable for the upcoming semester has been released. Please check the notice board and official website for your class schedules.",
                department: "Academic Section",
                author: "admin_001",
                timestamp: "2025-08-27T09:00:00Z",
                reactions: { "👍": 89, "😮": 12 },
                comments: [
                    {
                        id: 201,
                        content: "When does the new semester start?",
                        author: "user_321",
                        timestamp: "2025-08-27T10:00:00Z",
                        reactions: {"👍": 5},
                        replies: [
                            {
                                id: 202,
                                content: "According to the academic calendar, classes begin on September 15th.",
                                author: "user_654",
                                timestamp: "2025-08-27T10:30:00Z",
                                reactions: {"👍": 8},
                                replies: [
                                    {
                                        id: 203,
                                        content: "Perfect! That gives us enough time to prepare.",
                                        author: "user_321",
                                        timestamp: "2025-08-27T11:00:00Z",
                                        reactions: {"❤️": 2},
                                        replies: []
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                id: 4,
                type: "event",
                title: "Annual Technical Fest - Innovision 2025",
                description: "Get ready for the most exciting technical fest of the year! Multiple competitions, workshops, and tech talks by industry experts.",
                location: "Main Auditorium & Various Venues",
                date: "2025-09-20",
                time: "09:00",
                department: "Student Activity Center",
                author: "fest_committee",
                timestamp: "2025-08-26T14:00:00Z",
                responses: { going: 234, interested: 156, notGoing: 12 },
                reactions: { "🔥": 45, "❤️": 23, "😮": 18, "👍": 67 },
                comments: []
            },
            {
                id: 5,
                type: "lost_found",
                title: "Found: Blue Water Bottle",
                description: "Found a blue water bottle near the mechanical engineering block this morning. Has some stickers on it. Contact me to claim it.",
                location: "Mechanical Engineering Block",
                itemType: "found",
                author: "user_888",
                timestamp: "2025-08-29T08:15:00Z",
                reactions: { "👍": 15, "❤️": 3 },
                comments: []
            }
        ];

        this.reactionTypes = ["👍", "❤️", "😂", "😮", "😢", "😡", "🔥"];
        this.departments = [
            "Computer Science & Engineering", "Mechanical Engineering", 
            "Electrical Engineering", "Civil Engineering", "Academic Section",
            "Student Activity Center", "Library", "Administration"
        ];
        this.campusLocations = [
            "Central Library", "Main Auditorium", "CSE Lab", "Mechanical Engineering Block",
            "Electrical Engineering Block", "Student Activity Center", "Academic Building",
            "Hostel Area", "Sports Complex", "Cafeteria"
        ];
    }

    bindEventListeners() {
        // Smart input handling
        const smartInput = document.getElementById('smart-input');
        const classificationIndicator = document.getElementById('classification-indicator');
        
        smartInput.addEventListener('input', (e) => {
            this.handleSmartInput(e.target.value);
        });

        smartInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                this.generatePreview();
            }
        });

        // Preview actions
        document.getElementById('publish-btn').addEventListener('click', () => {
            this.publishPost();
        });

        document.getElementById('cancel-preview').addEventListener('click', () => {
            this.hidePreview();
        });

        document.getElementById('close-preview').addEventListener('click', () => {
            this.hidePreview();
        });

        // Filter buttons
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.setFilter(e.target.dataset.filter);
            });
        });

        // Modal handling
        this.bindModalEvents();

        // File upload
        document.getElementById('attach-btn').addEventListener('click', () => {
            document.getElementById('file-modal').classList.remove('hidden');
        });
    }

    bindModalEvents() {
        // Comment modal
        document.getElementById('close-comment-modal').addEventListener('click', () => {
            document.getElementById('comment-modal').classList.add('hidden');
        });

        document.getElementById('post-comment-btn').addEventListener('click', () => {
            this.postComment();
        });

        // File modal
        document.getElementById('close-file-modal').addEventListener('click', () => {
            document.getElementById('file-modal').classList.add('hidden');
        });

        // Modal overlay clicks
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                e.target.closest('.modal').classList.add('hidden');
            });
        });

        // File input handling
        document.getElementById('file-input').addEventListener('change', (e) => {
            this.handleFileUpload(e.target.files[0]);
        });

        document.getElementById('remove-file').addEventListener('click', () => {
            this.removeFile();
        });
    }

    initSmartInput() {
        const indicator = document.getElementById('classification-indicator');
        indicator.innerHTML = '<span class="indicator-text">Type to see AI classification...</span>';
    }

    // Smart AI-powered text classification (simulated)
    classifyText(text) {
        const lowerText = text.toLowerCase();
        
        // Event patterns
        const eventKeywords = [
            'workshop', 'seminar', 'event', 'fest', 'competition', 'meeting',
            'tomorrow', 'next week', 'saturday', 'sunday', 'pm', 'am',
            'auditorium', 'lab', 'hall', 'venue', 'join us', 'participate'
        ];

        // Lost & Found patterns
        const lostFoundKeywords = [
            'lost', 'found', 'missing', 'wallet', 'phone', 'book', 'keys',
            'bag', 'laptop', 'near', 'library', 'hostel', 'canteen',
            'yesterday', 'today', 'morning', 'evening', 'contact', 'claim'
        ];

        // Announcement patterns
        const announcementKeywords = [
            'notice', 'announcement', 'department', 'administration', 'circular',
            'timetable', 'schedule', 'exam', 'semester', 'registration',
            'important', 'attention', 'all students', 'hereby', 'informed'
        ];

        let eventScore = 0;
        let lostFoundScore = 0;
        let announcementScore = 0;

        // Calculate scores
        eventKeywords.forEach(keyword => {
            if (lowerText.includes(keyword)) eventScore++;
        });

        lostFoundKeywords.forEach(keyword => {
            if (lowerText.includes(keyword)) lostFoundScore++;
        });

        announcementKeywords.forEach(keyword => {
            if (lowerText.includes(keyword)) announcementScore++;
        });

        // Determine classification
        if (eventScore > lostFoundScore && eventScore > announcementScore && eventScore > 0) {
            return 'event';
        } else if (lostFoundScore > announcementScore && lostFoundScore > 0) {
            return 'lost_found';
        } else if (announcementScore > 0) {
            return 'announcement';
        }

        return 'neutral';
    }

    handleSmartInput(text) {
        const indicator = document.getElementById('classification-indicator');
        
        if (text.trim().length === 0) {
            indicator.className = 'classification-indicator neutral';
            indicator.innerHTML = '<span class="indicator-text">Type to see AI classification...</span>';
            return;
        }

        const classification = this.classifyText(text);
        indicator.className = `classification-indicator ${classification}`;
        
        const classificationText = {
            'event': '🎯 Detected: Event Post',
            'lost_found': '🔍 Detected: Lost & Found',
            'announcement': '📢 Detected: Announcement',
            'neutral': '💬 General Post'
        };

        indicator.innerHTML = `<span class="indicator-text">${classificationText[classification]}</span>`;

        if (text.length > 20) {
            setTimeout(() => {
                const previewBtn = document.createElement('button');
                previewBtn.className = 'btn btn--primary btn--sm';
                previewBtn.textContent = 'Generate Preview';
                previewBtn.onclick = () => this.generatePreview();
                
                if (!indicator.querySelector('button')) {
                    indicator.appendChild(previewBtn);
                }
            }, 1000);
        }
    }

    generatePreview() {
        const input = document.getElementById('smart-input');
        const text = input.value.trim();
        
        if (text.length === 0) return;

        const classification = this.classifyText(text);
        const preview = this.createPreviewForm(text, classification);
        
        document.getElementById('preview-content').innerHTML = preview;
        document.getElementById('post-preview').classList.remove('hidden');
        document.getElementById('post-preview').classList.add('fade-in');
    }

    createPreviewForm(text, type) {
        const extractedData = this.extractDataFromText(text);
        
        let form = '<div class="preview-form">';
        
        // Title and description for all types
        form += `
            <div class="form-group">
                <label class="form-label">Title</label>
                <input type="text" id="preview-title" class="form-control" value="${extractedData.title}">
            </div>
            <div class="form-group">
                <label class="form-label">Description</label>
                <textarea id="preview-description" class="form-control" rows="3">${extractedData.description}</textarea>
            </div>
        `;

        if (type === 'event') {
            form += `
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Date</label>
                        <input type="date" id="preview-date" class="form-control" value="${extractedData.date}">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Time</label>
                        <input type="time" id="preview-time" class="form-control" value="${extractedData.time}">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Location</label>
                        <select id="preview-location" class="form-control">
                            ${this.campusLocations.map(loc => 
                                `<option value="${loc}" ${loc === extractedData.location ? 'selected' : ''}>${loc}</option>`
                            ).join('')}
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Department</label>
                        <select id="preview-department" class="form-control">
                            ${this.departments.map(dept => 
                                `<option value="${dept}" ${dept === extractedData.department ? 'selected' : ''}>${dept}</option>`
                            ).join('')}
                        </select>
                    </div>
                </div>
            `;
        } else if (type === 'lost_found') {
            form += `
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Type</label>
                        <select id="preview-item-type" class="form-control">
                            <option value="lost" ${extractedData.itemType === 'lost' ? 'selected' : ''}>Lost Item</option>
                            <option value="found" ${extractedData.itemType === 'found' ? 'selected' : ''}>Found Item</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Location</label>
                        <select id="preview-location" class="form-control">
                            ${this.campusLocations.map(loc => 
                                `<option value="${loc}" ${loc === extractedData.location ? 'selected' : ''}>${loc}</option>`
                            ).join('')}
                        </select>
                    </div>
                </div>
            `;
        } else if (type === 'announcement') {
            form += `
                <div class="form-group">
                    <label class="form-label">Department</label>
                    <select id="preview-department" class="form-control">
                        ${this.departments.map(dept => 
                            `<option value="${dept}" ${dept === extractedData.department ? 'selected' : ''}>${dept}</option>`
                        ).join('')}
                    </select>
                </div>
            `;
        }

        form += '</div>';
        return form;
    }

    extractDataFromText(text) {
        const data = {
            title: this.extractTitle(text),
            description: text,
            date: this.extractDate(text),
            time: this.extractTime(text),
            location: this.extractLocation(text),
            department: this.extractDepartment(text),
            itemType: this.extractItemType(text)
        };

        return data;
    }

    extractTitle(text) {
        const sentences = text.split(/[.!?]/);
        const firstSentence = sentences[0].trim();
        return firstSentence.length > 50 ? firstSentence.substring(0, 50) + '...' : firstSentence;
    }

    extractDate(text) {
        const today = new Date();
        const lowerText = text.toLowerCase();
        
        if (lowerText.includes('tomorrow')) {
            const tomorrow = new Date(today);
            tomorrow.setDate(today.getDate() + 1);
            return tomorrow.toISOString().split('T')[0];
        } else if (lowerText.includes('next week')) {
            const nextWeek = new Date(today);
            nextWeek.setDate(today.getDate() + 7);
            return nextWeek.toISOString().split('T')[0];
        }
        
        return today.toISOString().split('T')[0];
    }

    extractTime(text) {
        const timeMatch = text.match(/(\d{1,2}):?(\d{2})?\s*(pm|am)/i);
        if (timeMatch) {
            let hours = parseInt(timeMatch[1]);
            const minutes = timeMatch[2] || '00';
            const period = timeMatch[3].toLowerCase();
            
            if (period === 'pm' && hours !== 12) hours += 12;
            if (period === 'am' && hours === 12) hours = 0;
            
            return `${hours.toString().padStart(2, '0')}:${minutes}`;
        }
        return '17:00';
    }

    extractLocation(text) {
        const lowerText = text.toLowerCase();
        for (const location of this.campusLocations) {
            if (lowerText.includes(location.toLowerCase())) {
                return location;
            }
        }
        return this.campusLocations[0];
    }

    extractDepartment(text) {
        const lowerText = text.toLowerCase();
        for (const dept of this.departments) {
            if (lowerText.includes(dept.toLowerCase())) {
                return dept;
            }
        }
        return this.departments[0];
    }

    extractItemType(text) {
        const lowerText = text.toLowerCase();
        if (lowerText.includes('found')) return 'found';
        if (lowerText.includes('lost')) return 'lost';
        return 'lost';
    }

    publishPost() {
        const type = this.classifyText(document.getElementById('smart-input').value);
        const newPost = {
            id: Date.now(),
            type: type,
            title: document.getElementById('preview-title').value,
            description: document.getElementById('preview-description').value,
            author: 'current_user',
            timestamp: new Date().toISOString(),
            reactions: {},
            comments: []
        };

        // Add type-specific fields
        if (type === 'event') {
            newPost.date = document.getElementById('preview-date').value;
            newPost.time = document.getElementById('preview-time').value;
            newPost.location = document.getElementById('preview-location').value;
            newPost.department = document.getElementById('preview-department').value;
            newPost.responses = { going: 0, interested: 0, notGoing: 0 };
        } else if (type === 'lost_found') {
            newPost.itemType = document.getElementById('preview-item-type').value;
            newPost.location = document.getElementById('preview-location').value;
        } else if (type === 'announcement') {
            newPost.department = document.getElementById('preview-department').value;
        }

        this.posts.unshift(newPost);
        this.renderFeed();
        this.hidePreview();
        document.getElementById('smart-input').value = '';
        this.initSmartInput();
        
        // Update total posts count
        document.getElementById('total-posts').textContent = this.posts.length;
    }

    hidePreview() {
        document.getElementById('post-preview').classList.add('hidden');
    }

    setFilter(filter) {
        this.currentFilter = filter;
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-filter="${filter}"]`).classList.add('active');
        this.renderFeed();
    }

    renderFeed() {
        const container = document.getElementById('feed-container');
        const filteredPosts = this.currentFilter === 'all' 
            ? this.posts 
            : this.posts.filter(post => post.type === this.currentFilter);

        if (filteredPosts.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">📭</div>
                    <h3>No posts found</h3>
                    <p>Be the first to post something!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = filteredPosts.map(post => this.renderPost(post)).join('');
        this.bindPostEvents();
    }

    renderPost(post) {
        const typeConfig = {
            event: { icon: '🎯', label: 'Event' },
            lost_found: { icon: '🔍', label: 'Lost & Found' },
            announcement: { icon: '📢', label: 'Announcement' }
        };

        const config = typeConfig[post.type];
        const timeAgo = this.getTimeAgo(post.timestamp);

        let postDetails = '';
        if (post.type === 'event') {
            const eventDate = new Date(`${post.date}T${post.time}`);
            postDetails = `
                <div class="post-details">
                    <div class="post-detail">
                        <span class="detail-icon">📅</span>
                        <span>${eventDate.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
                    </div>
                    <div class="post-detail">
                        <span class="detail-icon">⏰</span>
                        <span>${eventDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div class="post-detail">
                        <span class="detail-icon">📍</span>
                        <span>${post.location}</span>
                    </div>
                    <div class="post-detail">
                        <span class="detail-icon">🏢</span>
                        <span>${post.department}</span>
                    </div>
                </div>
            `;
        } else if (post.type === 'lost_found') {
            postDetails = `
                <div class="post-details">
                    <div class="post-detail">
                        <span class="detail-icon">${post.itemType === 'lost' ? '❌' : '✅'}</span>
                        <span>${post.itemType === 'lost' ? 'Lost Item' : 'Found Item'}</span>
                    </div>
                    <div class="post-detail">
                        <span class="detail-icon">📍</span>
                        <span>${post.location}</span>
                    </div>
                </div>
            `;
        } else if (post.type === 'announcement') {
            postDetails = `
                <div class="post-details">
                    <div class="post-detail">
                        <span class="detail-icon">🏢</span>
                        <span>${post.department}</span>
                    </div>
                </div>
            `;
        }

        let eventResponses = '';
        if (post.type === 'event' && post.responses) {
            eventResponses = `
                <div class="event-responses">
                    <button class="response-btn ${this.userResponses.get(post.id) === 'going' ? 'active' : ''}" 
                            data-post-id="${post.id}" data-response="going">
                        ✅ Going <span class="response-count">${post.responses.going}</span>
                    </button>
                    <button class="response-btn ${this.userResponses.get(post.id) === 'interested' ? 'active' : ''}" 
                            data-post-id="${post.id}" data-response="interested">
                        🤔 Interested <span class="response-count">${post.responses.interested}</span>
                    </button>
                    <button class="response-btn ${this.userResponses.get(post.id) === 'notGoing' ? 'active' : ''}" 
                            data-post-id="${post.id}" data-response="notGoing">
                        ❌ Not Going <span class="response-count">${post.responses.notGoing}</span>
                    </button>
                </div>
            `;
        }

        const reactionsBar = this.renderReactionsBar(post);
        const commentCount = this.getCommentCount(post.comments);

        return `
            <article class="card post-card slide-up">
                <div class="card__body">
                    <div class="post-header">
                        <div class="post-meta">
                            <div class="post-type-badge ${post.type}">
                                ${config.icon} ${config.label}
                            </div>
                            <div class="post-timestamp">${timeAgo}</div>
                        </div>
                    </div>
                    
                    <h2 class="post-title">${post.title}</h2>
                    <p class="post-description">${post.description}</p>
                    
                    ${postDetails}
                    ${eventResponses}
                    
                    <div class="post-actions">
                        ${reactionsBar}
                        <div class="action-buttons">
                            <button class="action-btn" data-post-id="${post.id}" data-action="comment">
                                💬 Comment ${commentCount > 0 ? `(${commentCount})` : ''}
                            </button>
                        </div>
                    </div>
                </div>
            </article>
        `;
    }

    renderReactionsBar(post) {
        const reactions = post.reactions || {};
        return `
            <div class="reactions-bar">
                ${this.reactionTypes.map(emoji => {
                    const count = reactions[emoji] || 0;
                    const isActive = this.userReactions.get(`${post.id}-${emoji}`) || false;
                    return `
                        <button class="reaction-btn ${isActive ? 'active' : ''}" 
                                data-post-id="${post.id}" data-reaction="${emoji}">
                            <span class="reaction-emoji">${emoji}</span>
                            <span class="reaction-count">${count}</span>
                        </button>
                    `;
                }).join('')}
            </div>
        `;
    }

    getCommentCount(comments) {
        let count = comments.length;
        comments.forEach(comment => {
            count += this.getCommentCount(comment.replies || []);
        });
        return count;
    }

    bindPostEvents() {
        // Reaction buttons
        document.querySelectorAll('.reaction-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const postId = parseInt(e.currentTarget.dataset.postId);
                const reaction = e.currentTarget.dataset.reaction;
                this.toggleReaction(postId, reaction);
            });
        });

        // Response buttons (for events)
        document.querySelectorAll('.response-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const postId = parseInt(e.currentTarget.dataset.postId);
                const response = e.currentTarget.dataset.response;
                this.setResponse(postId, response);
            });
        });

        // Comment buttons
        document.querySelectorAll('[data-action="comment"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const postId = parseInt(e.currentTarget.dataset.postId);
                this.openCommentModal(postId);
            });
        });
    }

    toggleReaction(postId, reaction) {
        const post = this.posts.find(p => p.id === postId);
        if (!post) return;

        const reactionKey = `${postId}-${reaction}`;
        const isActive = this.userReactions.get(reactionKey);

        if (isActive) {
            post.reactions[reaction] = Math.max(0, (post.reactions[reaction] || 0) - 1);
            this.userReactions.delete(reactionKey);
        } else {
            post.reactions[reaction] = (post.reactions[reaction] || 0) + 1;
            this.userReactions.set(reactionKey, true);
        }

        this.renderFeed();
    }

    setResponse(postId, response) {
        const post = this.posts.find(p => p.id === postId);
        if (!post || !post.responses) return;

        const currentResponse = this.userResponses.get(postId);
        
        // Remove current response
        if (currentResponse) {
            post.responses[currentResponse] = Math.max(0, post.responses[currentResponse] - 1);
        }

        // Add new response if different
        if (currentResponse !== response) {
            post.responses[response] = (post.responses[response] || 0) + 1;
            this.userResponses.set(postId, response);
        } else {
            this.userResponses.delete(postId);
        }

        this.renderFeed();
    }

    openCommentModal(postId) {
        this.currentPostId = postId;
        const post = this.posts.find(p => p.id === postId);
        
        const commentsContainer = document.getElementById('comments-container');
        commentsContainer.innerHTML = this.renderComments(post.comments);
        
        document.getElementById('comment-modal').classList.remove('hidden');
        this.bindCommentEvents();
    }

    renderComments(comments, level = 0) {
        return comments.map(comment => `
            <div class="comment" style="margin-left: ${level * 20}px;">
                <div class="comment-header">
                    <span class="comment-author">${comment.author}</span>
                    <span class="comment-timestamp">${this.getTimeAgo(comment.timestamp)}</span>
                </div>
                <div class="comment-content">${comment.content}</div>
                <div class="comment-actions">
                    ${this.renderCommentReactions(comment)}
                    <button class="action-btn btn--sm" data-comment-id="${comment.id}" data-action="reply">
                        💬 Reply
                    </button>
                </div>
                <div class="comment-replies">
                    ${comment.replies ? this.renderComments(comment.replies, level + 1) : ''}
                </div>
            </div>
        `).join('');
    }

    renderCommentReactions(comment) {
        const reactions = comment.reactions || {};
        return `
            <div class="reactions-bar">
                ${Object.entries(reactions).map(([emoji, count]) => `
                    <button class="reaction-btn btn--sm" data-comment-id="${comment.id}" data-reaction="${emoji}">
                        <span class="reaction-emoji">${emoji}</span>
                        <span class="reaction-count">${count}</span>
                    </button>
                `).join('')}
            </div>
        `;
    }

    bindCommentEvents() {
        // Reply buttons
        document.querySelectorAll('[data-action="reply"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const commentId = parseInt(e.currentTarget.dataset.commentId);
                this.showReplyInput(commentId);
            });
        });
    }

    showReplyInput(commentId) {
        // Simple implementation - could be enhanced with inline reply inputs
        const content = prompt('Enter your reply:');
        if (content && content.trim()) {
            this.addReply(commentId, content.trim());
        }
    }

    addReply(parentCommentId, content) {
        const post = this.posts.find(p => p.id === this.currentPostId);
        if (!post) return;

        const newReply = {
            id: ++this.commentCounter,
            content: content,
            author: 'current_user',
            timestamp: new Date().toISOString(),
            reactions: {},
            replies: []
        };

        this.addReplyToComment(post.comments, parentCommentId, newReply);
        this.openCommentModal(this.currentPostId); // Refresh modal
    }

    addReplyToComment(comments, parentId, newReply) {
        for (const comment of comments) {
            if (comment.id === parentId) {
                comment.replies = comment.replies || [];
                comment.replies.push(newReply);
                return true;
            }
            if (comment.replies && this.addReplyToComment(comment.replies, parentId, newReply)) {
                return true;
            }
        }
        return false;
    }

    postComment() {
        const input = document.getElementById('comment-input');
        const content = input.value.trim();
        
        if (!content || !this.currentPostId) return;

        const post = this.posts.find(p => p.id === this.currentPostId);
        if (!post) return;

        const newComment = {
            id: ++this.commentCounter,
            content: content,
            author: 'current_user',
            timestamp: new Date().toISOString(),
            reactions: {},
            replies: []
        };

        post.comments.push(newComment);
        input.value = '';
        
        this.openCommentModal(this.currentPostId); // Refresh modal
        this.renderFeed(); // Update comment count
    }

    handleFileUpload(file) {
        if (!file) return;

        const preview = document.getElementById('file-preview');
        const fileName = document.getElementById('file-name');
        
        fileName.textContent = file.name;
        preview.classList.remove('hidden');
        
        document.getElementById('file-modal').classList.add('hidden');
    }

    removeFile() {
        document.getElementById('file-preview').classList.add('hidden');
        document.getElementById('file-input').value = '';
    }

    getTimeAgo(timestamp) {
        const now = new Date();
        const postTime = new Date(timestamp);
        const diffInSeconds = Math.floor((now - postTime) / 1000);

        if (diffInSeconds < 60) {
            return 'Just now';
        } else if (diffInSeconds < 3600) {
            const minutes = Math.floor(diffInSeconds / 60);
            return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        } else if (diffInSeconds < 86400) {
            const hours = Math.floor(diffInSeconds / 3600);
            return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        } else {
            const days = Math.floor(diffInSeconds / 86400);
            return `${days} day${days > 1 ? 's' : ''} ago`;
        }
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CampusFeedApp();
});